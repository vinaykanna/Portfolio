import { Github, Linkedin, Location, Mail, Phone } from "../icons";

const fullName = "MADHUKAR MOGUTHALA";

const designation = "Technology Analyst";

const summary = `Dedicated Clarity Developer with 4 years of hands-on experience
        specializing in Clarity PPM, NSQL, XML, and GEL scripting within the
        dynamic environment of Infosys. Proficient in designing, configuring,
        and optimizing Clarity PPM solutions to drive project and portfolio
        management excellence. Adept at collaborating with cross-functional
        teams to deliver scalable and efficient solutions that enhance
        organizational performance.`;

const skills = [
  "HTML",
  "CSS",
  "MySQL",
  "ClarityPPM",
  "NSQL",
  "XML",
  "GelScripting",
  "Jasper Soft",
  "Rest API",      
];

const education = [
  {
    title: "Bachelor of Technology (Mechanical)",
    college: "Jawaharlal Nehru Technological University Hyderabad",
    period: "2018 - 2021",
  },
];

const achievements = [
  {
    title: "Secured 2nd place in the hackathon",
    desc: "The hackathon was about developing User interface based on the requirements with the best possible UX.",
  },
];

const passions = [
  "Continuous learning and improvement in the tech",
  "Optimizing processes and delivering impactful solutions",
];

const languages = [
  {
    title: "Telugu",
    points: 5,
    proficiency: "Native",
  },
  {
    title: "English",
    points: 4,
    proficiency: "Proficient",
  },
  {
    title: "Hindi",
    points: 3,
    proficiency: "Intermediate",
  },
];

const experience = [
  {
    company: "Infosys",
    roles: [
      {
        title: "Technology Analyst",
        period: "11/2021 - 07/2025",
        location: "Hyderabad",
        work: [
          "Worked with 3 Banking Clients and Presently working with Car Manufacture Client.",
          "Implemented custom solutions using Clarity PPM, NSQL, XML, and Gel scripting to streamline project management processes.",
          "Developed and maintained NSQL queries and XML templates to extract and visualize critical project data for stakeholders.",
          "Automated repetitive tasks and improved efficiency by creating Gel scripts to enhance system functionality.",
          "Customized Clarity PPM workflows and configurations to align with specific project requirements and business needs.",
          "Enhanced reporting capabilities by designing and implementing custom reports and dashboards using Clarity PPM data.",
          "Played a key role in system upgrades and migrations, ensuring a smooth transition to newer versions of Clarity PPM.",
          "Knowledge of debugging of the processes, scripts for the issues faced by the global clarity users and resolving their queries efficiently.",
          "Experience of working on support tools – Service Now for handling Incidents, service requests and Change Requests.",
          "Experience in writing queries using SQL, Knowledge on using GEL Script for workflows in CA PPM.",
          "Built advance reports in the clarity with the help of Jasper Studio.",
          "Experience in interfacing with global clarity users efficiently and resolve their queries.",
          "supported the upgrades of the Clarity PPM from the version  15.9.1 and 16.1.0. And has tested and reported bugs in the lower environments for the various critical components and integrations before the upgrades.",
          "Experience in Clarity 15.x, 16.x versions.",
        ],
      },
    ],
  },
  {
    company: "Clarity PPM(VISA Banking)",
    roles: [
      {
        title: "Job Role:Clarity Support",
        period: "11/2021 - 11/2022",
        location: "Hyderabad",
        work: [
          "Managed Multiple projects using Clarity PPM, resulting in a 15% reduction in project delivery time.",
          "Developed and manitained project schedules, budget and resource plans in Clarity PPM.",
          "Customized Clarity PPM workflows and configurations to align with specific project requirements and business needs.",
          "Enhanced reporting capabilities by designing and implementing custom reports and dashboards using Clarity PPM data.",
          "Developed custom dashboards and widgets in the MUX environment, resulting in a 25% inccrease in project reporting effieciency.",
        ],
      },
    ],
  },
  {
    company: "Clarity PPM(Westpac Banking)",
    roles: [
      {
        title: "Job Role:Clarity Developer",
        period: "12/2022 - 11/2023",
        location: "Hyderabad",
        work: [
          "Managed Multiple projects using Clarity PPM, resulting in a 15% reduction in project delivery time.",
          "Implemented custom solutions using Clarity PPM, NSQL, XML, and Gel scripting to streamline project management processes.",
          "Developed and maintained NSQL queries and XML templates to extract and visualize critical project data for stakeholders.",
          "Automated repetitive tasks and improved efficiency by creating Gel scripts to enhance system functionality.",
          "Configured and optimized Clarity PPM MUX interface to enhance user experience and streamline project management process.",
          "Played a key role in system upgrades and migrations, ensuring a smooth transition to newer versions of Clarity PPM.",
        ],
      },
    ],
  },
  {
    company: "Clarity PPM(Nissan)",
    roles: [
      {
        title: "Job Role:Clarity Developer",
        period: "12/2023 - 07/2025",
        location: "Hyderabad",
        work: [
          "Reduced project management cycle  times by 20% by implementing cutom workflows in the Clarity PPM MUX.",
          "Increased user adoption of the MUX  interface by 40% through tailored configurations and training programs .",
          "Experience of working on support tools – Service Now for handling Incidents, service requests and Change Requests.",
          "Experience in writing queries using SQL, Knowledge on using GEL Script for workflows in CA PPM.",
          "Built advance reports in the clarity with the help of Jasper Studio.",
          "Experience in interfacing with global clarity users efficiently and resolve their queries.",
        ],
      },
    ],
  },
 {
    company: "TCS",
    roles: [
      {
        title: "System Engineer",
        period: "07/2025 - Present",
        location: "Hyderabad",
        work: [
          "Worked with 1 Banking Clients.",
          "Implemented custom solutions using Clarity PPM, NSQL, XML, and Gel scripting to streamline project management processes.",
          "Developed and maintained NSQL queries and XML templates to extract and visualize critical project data for stakeholders.",
          "Automated repetitive tasks and improved efficiency by creating Gel scripts to enhance system functionality.",
          "Customized Clarity PPM workflows and configurations to align with specific project requirements and business needs.",
          "Enhanced reporting capabilities by designing and implementing custom reports and dashboards using Clarity PPM data.",
          "Played a key role in system upgrades and migrations, ensuring a smooth transition to newer versions of Clarity PPM.",
          "Knowledge of debugging of the processes, scripts for the issues faced by the global clarity users and resolving their queries efficiently.",
          "Experience of working on support tools – Service Now for handling Incidents, service requests and Change Requests.",
          "Experience in writing queries using SQL, Knowledge on using GEL Script for workflows in CA PPM.",
          "Experience in interfacing with global clarity users efficiently and resolve their queries.",
          "supported the upgrades of the Clarity PPM from the version  15.9.1 and 16.1.0. And has tested and reported bugs in the lower environments for the various critical components and integrations before the upgrades.",
          "Experience in Clarity 15.x, 16.x versions.",
        ],
      },
    ],
  },
{
    company: "Clarity PPM(BMO)",
    roles: [
      {
        title: "Job Role:Clarity Developer",
        period: "07/2025 - Present",
        location: "Hyderabad",
        work: [
          "Designed and configured custom portlets and dashboards using NSQL to provide real-time project and resource visibility for leadership teams.",
          "Developed and automated GEL-based workflows to streamline approval processes, improving operational efficiency and reducing manual effort.",
          "Performed Clarity PPM system enhancements, including custom object creation, attribute configuration, and lookup management to meet evolving business requirements.",
          "Collaborated closely with functional and business users to gather requirements, perform impact analysis, and deliver tailored Clarity solutions.",
          "Optimized Clarity PPM performance through query tuning and data cleanup, reducing report load times and improving user experience.",
        ],
      },
    ],
  },
];

const headerItems = [
  {
    title: "8465883620",
    icon: Phone,
  },
  {
    title: "Hyderabad",
    icon: Location,
  },
  {
    title: "madhugoud2403@gmail.com",
    icon: Mail,
  },
  {
    title: "Linkedin",
    icon: Linkedin,
    link: "https://www.linkedin.com/in/madhukar-moguthala-981200210/",
  },
];

export {
  fullName,
  skills,
  education,
  headerItems,
  designation,
  achievements,
  passions,
  languages,
  experience,
  summary,
};
